package com.edu.faiz.training.myfirstservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyFirstServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
